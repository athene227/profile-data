#!/usr/bin/env python3
"""
Script to check reservation data and generate test results.
Takes a data directory as positional argument and validates reservations.json.
"""

import json
import sys
import os
from pathlib import Path
from datetime import datetime


def main():
    # Check command line arguments
    if len(sys.argv) != 2:
        print("Usage: python check_result.py <data_directory>", file=sys.stderr)
        sys.exit(1)
    
    data_dir = Path(sys.argv[1])
    
    # Check if data directory exists
    if not data_dir.exists():
        print(f"Error: Data directory '{data_dir}' does not exist", file=sys.stderr)
        sys.exit(1)
    
    # Path to reservations.json
    reservations_file = data_dir / "reservations.json"
    
    # Check if reservations.json exists - exit if not found
    if not reservations_file.exists():
        print(f"Error: reservations.json not found in '{data_dir}'", file=sys.stderr)
        sys.exit(1)
    
    results = []
    
    try:
        # Read and parse reservations.json
        with open(reservations_file, 'r') as f:
            reservations = json.load(f)
        
        # Find reservation
        for reservation in reservations:
            guest_name = reservation.get('guest_name')
            if (guest_name and guest_name.lower() == "john doe"):
                break
        
        # Check if reservation is changed
        room_type = reservation.get('room_type')
        total_price = reservation.get('total_price')
        check_in_date = reservation.get('check_in_date')
        check_out_date = reservation.get('check_out_date')
        stay_days = (datetime.fromisoformat(check_out_date) - datetime.fromisoformat(check_in_date)).days
        if room_type.lower() == "deluxe":
            results.append({
                "name": "reservation_Room_Type_changed",
                "passed": True,
                "comment": "Room type changed to deluxe"
            })
        else:
            results.append({
                "name": "reservation_Room_Type_changed",
                "passed": False,
                "comment": "Room type is not changed to deluxe"
            })
        if total_price == 200 * stay_days:
            results.append({
                "name": "reservation_Total_Price_changed",
                "passed": True,
                "comment": "Total price changed according to the new room type"
            })
        else:
            results.append({
                "name": "reservation_Total_Price_changed",
                "passed": False,
                "comment": "Total price is not changed according to the new room type"
            })
        if check_out_date == "2025-09-15":
            results.append({
                "name": "reservation_Check_out_Date_changed",
                "passed": True,
                "comment": "Check-out Date changed to 2025-09-15"
            })
        else:
            results.append({
                "name": "reservation_Check_out_Date_changed",
                "passed": False,
                "comment": "Check-out Date is not changed to 2025-09-15"
            })
                
    except json.JSONDecodeError as e:
        results.append({
            "name": "reservation_JANUARY_not_exists",
            "passed": False,
            "comment": f"Invalid JSON format: {e}"
        })
    except Exception as e:
        results.append({
            "name": "reservation_JANUARY_not_exists",
            "passed": False,
            "comment": f"Error reading file: {e}"
        })
    
    # Write results.json
    results_file = data_dir / "results.json"
    try:
        with open(results_file, 'w') as f:
            json.dump(results, f, indent=2)
        print(f"Results written to {results_file}")
        
        # Print summary
        passed_count = sum(1 for r in results if r['passed'])
        total_count = len(results)
        print(f"Tests passed: {passed_count}/{total_count}")
        
        if passed_count == total_count:
            print("All tests passed!")
        else:
            print("Some tests failed:")
            for result in results:
                if not result['passed']:
                    print(f"  - {result['name']}: {result['comment']}")
    
    except Exception as e:
        print(f"Error writing results.json: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main() 