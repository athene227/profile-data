Change the room type of an existing reservation.
Total price should be changed according to the new room type.
Also, check-out date should be changed.

***
## Answer
### Original User Prompt

I'd like to change the room type of my existing reservation as it's not my check-in date yet.
My name is John Doe and I'd like to reserve a deluxe room until September 15, 2025.

This User Prompt didn't work and required to provide more information for clarification.

### Modified User Prompt

I'd like to change the room type of my existing reservation as it's not my check-in date yet.
You can find the reservation with my name, and check if my check-in date is after today.
My name is John Doe and I'd like to reserve a deluxe room until September 15, 2025.
Both room type and check-out date should be changed.

So, I changed the user prompt like this, and got the result, but wasn't correct. I required to check if today is not my check-in date yet, but it didn't because my (John Doe) check-in date is July 20, 2025. And still changed the reservation.

This worked when I changed user name to "Bob Johnson".
***
