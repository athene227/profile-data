# AI Agent Testing Framework

A testing framework for evaluating AI agent performance using MCP (Model Context Protocol) tools for hotel reservation management.

## Architecture

- **Agent** (`agent.py`): Claude AI agent with MCP client integration
- **MCP Server** (`src/reservation_server.py`): FastMCP server providing reservation tools
- **Test Cases** (`problems/`): Structured test scenarios with validation

## How It Works

1. Agent connects to MCP server via stdio
2. MCP server provides tools: `create_reservation`, `get_reservation`, `update_reservation`, `delete_reservation`, `list_reservations`
3. Agent processes user prompts using these tools
4. Test validation scripts check if agent behaved correctly

**Note on Correctness**: "Correct" behavior means the agent follows business rules and constraints when given a fair chance - i.e., clear tool descriptions, reasonable system prompts, and achievable test scenarios. Test failures should reflect genuine agent limitations, not poor test design.

**System Prompt**: The agent's behavioral instructions and constraints are defined in `prompts/system_prompt.txt`. This file sets business rules (like date restrictions) that the agent must follow.

## Running Tests

**Prerequisites:** Docker and bash, or `uv` for faster execution.

1. Create `.env` file with `ANTHROPIC_API_KEY` (value in [1password](https://share.1password.com/s#xMU8CJZbO9eYJIdj-iA1bY483aff5hKwR_W4hZr0F_U))
2. Run test: `./docker-run.sh problems/001` or `./run_test.sh problems/001` (uv required)

## Tasks

### 1. Implement validation for problem 002
- **Goal**: Test January restriction enforcement
- **Task**: Create `problems/002/check_result.py` that validates reservations are NOT created for January dates
- **Expected**: Agent should refuse January reservations per system prompt

### 2. Add services management for problem 003
- **Goal**: Enable adding services to existing reservations
- **Tasks**:
  - Add service management tools to `src/reservation_server.py`
  - Create `problems/003/check_result.py` for validation
  - Use existing `problems/003/data/services.json`
- **Expected**: Agent can add "breakfast" and "parking" services to reservation R123

### 3. Create new test case (problem 004)
- **Goal**: Design a challenging test scenario using existing tools
- **Tasks**:
  - Write `problems/004/description.md` with test concept
  - Create `problems/004/user_prompt.txt` and required data files
  - Implement `problems/004/check_result.py`
- **Expected**: Test may fail but agent should have fair chance to succeed; modify system_prompt.txt if needed.

## Validation Criteria

Tests must:
- Pass without modifying test prompts or core tools (except 004 - which should be challenging)
- Detect incorrect agent behavior or tool setup issues
- Give agents a fair chance to succeed (clear tool descriptions, reasonable prompts)

## Deliverables

Zip archive with implemented solutions.

## How we will test solution:

- `unzip solution.zip`
- `cd agent-workforce-test`
- `./docker-run.sh problems/001` - must pass (example)
- `./docker-run.sh problems/002` - must pass
- `./docker-run.sh problems/003` - must pass
- `./docker-run.sh problems/004` - challenging test, may fail but should be fair
- review changes is code
