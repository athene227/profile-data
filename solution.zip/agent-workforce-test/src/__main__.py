"""
Main entry point for the FastMCP reservation server.
"""
from .reservation_server import main

if __name__ == "__main__":
    main() 