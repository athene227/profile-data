"""
Service data model for the MCP server.
"""
from datetime import date
from typing import Optional
from pydantic import BaseModel, Field, validator


class Service(BaseModel):
    """Hotel service model."""
    id: str = Field(description="Unique service ID")
    name: str = Field(description="Name of the service")
    description: str = Field(description="Description of the service")
    price: float = Field(description="Price of the service")
    category: str = Field(description="Category of the service")
    reservation_id: str = Field(description="Reservation ID associated with the service")

    @validator('id')
    def validate_id_not_empty(cls, v: str) -> str:
        """Ensure ID is not empty."""
        if not v.strip():
            raise ValueError('Reservation ID cannot be empty')
        return v.strip()

    @validator('name')
    def validate_name_not_empty(cls, v: str) -> str:
        """Ensure name is not empty."""
        if not v.strip():
            raise ValueError('Name cannot be empty')
        return v.strip()

    @validator('category')
    def validate_category_not_empty(cls, v: str) -> str:
        """Ensure category is not empty."""
        if not v.strip():
            raise ValueError('Category cannot be empty')
        return v.strip()

    @validator('reservation_id')
    def validate_reservation_id_not_empty(cls, v: str) -> str:
        """Ensure reservation_id is not empty."""
        if not v.strip():
            raise ValueError('Reservation ID cannot be empty')
        return v.strip()
    
    class Config:
        """Pydantic configuration."""
        json_encoders = {
            date: lambda v: v.isoformat()
        }
        json_schema_extra = {
            "example": {
                "id": "S002",
                "name": "Parking",
                "description": "Daily parking in hotel garage",
                "price": 15.0,
                "category": "parking",
                "reservation_id": "R125"
            }
        } 